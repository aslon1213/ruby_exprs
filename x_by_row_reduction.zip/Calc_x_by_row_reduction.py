from black import out
import generate_matrix
import json
import sympy as sym

def row_reduction(A):
    # A = sym.Matrix(A)
    # A = A.rref(pivots = False)
    # # for i in range(10):
    # #     print(A[10 * i],A[10 * i+1],A[10 * i + 2],A[i],A[10 * i + 3],A[10 * i + 4],A[10 * i + 5],A[10 * i + 6],A[10 * i + 7],A[10 * i + 8],A[10 * i + 9],A[10 * i + 10],A[10 * i+11],A[10 * i + 12],A[i],A[10 * i + 13],A[10 * i + 14],A[10 * i + 15],A[10 * i + 16],A[10 * i + 17],A[10 * i + 18],A[10 * i + 19])
    # #A = A.to_list()
    size = len(A)
    for i in range(size):
        for j in range(size):
            if i != j:
                temp = A[j][i] / A[i][i]
                for k in range(2 * size):
                    A[j][k] -= A[i][k] * temp
    for i in range(size):
        temp = A[i][i]
        for j in range(size * 2):
            A[i][j] = A[i][j] / temp
    output = []
    for i in range(size):
        A[i] = A[i][size:(size * 2)]
    return A


def make_inverse_of_A(A):
    output = []
    row_size = len(A)

    # make augmented matrix by adding I(n)
    for i in range(row_size):
        a = A[i]
        for j in range(row_size):
            if i != j:
                a.append(0)
            else:
                a.append(1)

    # row reduction
    A = row_reduction(A)
    return A


def calculate_multiplication(A,B,size):
    output = []
    for row in A:
        o = []
        for i in range(size):
            column = []
            for j in range(size):
                column.append(B[j][i])
            val = 0
            for j in range(size):
                val += row[j] * column[j]
            o.append(val)
        output.append(o)

    return output
        
def print_matrix(ffff):
    for f in ffff:
        output = '| '
        for j in f:
            output += str(j) + " "
        output += "|"
        print(output)


with open('AB.json', "r") as file:
    AB = json.load(file)
    # A = [[3, 4], [5, 6]]
    # B = [[7,7],[11,11]]
    A = AB["A"]
    B = AB["B"]
    print("Matrix A")
    print_matrix(A)
    print("Matrix B")
    print_matrix(B)
    print("Matrix X")
    A = make_inverse_of_A(A)
    X = calculate_multiplication(A,B,len(B))
    print_matrix(X)
    with open("X.json", 'w') as outputfile:
        outputfile.write(json.dumps({"X":X}))


# A = [[3, 4], [5, 6]]
# B = [[1,1],[1,1]]

# print(calculate_multiplication(A,B,2))